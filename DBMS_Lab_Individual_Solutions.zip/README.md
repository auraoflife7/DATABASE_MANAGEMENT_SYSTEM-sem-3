# DBMS Lab Assignments (Oracle SQL)

Individual `.sql` solution files organized by assignment folder for GitHub upload.

## Folder Structure

* **`Assignment_04/`** — 20 individual files (Constraints, DDL, DML, Integrity Verification)
* **`Assignment_06/`** — 30 individual files (Aggregates, `ORDER BY`, `GROUP BY`, `HAVING`, Date Formatting)
* **`Assignment_07/`** — 26 individual files (`00_setup` + 25 Single-Row Function solutions)
* **`Assignment_08/`** — 15 individual files (Set Operators: `UNION`, `UNION ALL`, `INTERSECT`, `MINUS`)
* **`Assignment_09/`** — 17 individual files (Multi-table Joins & Self-Joins)
