-- 1. Create a table EMP with following structure and insert rows.
CREATE TABLE EMP (
    E_ID NUMBER(5) PRIMARY KEY,
    FNAME VARCHAR2(20) NOT NULL,
    LNAME VARCHAR2(20) NOT NULL,
    HIRE_DATE DATE NOT NULL,
    JOB_ID VARCHAR2(15) NOT NULL,
    SAL NUMBER(8, 2) NOT NULL,
    DEPT_ID NUMBER(4) CHECK (DEPT_ID >= 10)
);

INSERT INTO EMP VALUES (198, 'Donald', 'Connell', TO_DATE('21-Jun-99', 'DD-Mon-RR'), 'SH_CLERK', 2600, 50);
INSERT INTO EMP VALUES (199, 'Douglas', 'Grant', TO_DATE('13-Jan-98', 'DD-Mon-RR'), 'SH_CLERK', 3000, 50);
INSERT INTO EMP VALUES (200, 'Jennifer', 'Whalen', TO_DATE('17-Sep-87', 'DD-Mon-RR'), 'AD_ASST', 4400, 10);
INSERT INTO EMP VALUES (201, 'Michael', 'Hartstein', TO_DATE('19-Jan-99', 'DD-Mon-RR'), 'IT_PROG', 6000, 20);
INSERT INTO EMP VALUES (202, 'Pat', 'Fay', TO_DATE('25-Oct-89', 'DD-Mon-RR'), 'AC_MGR', 6500, 20);
INSERT INTO EMP VALUES (203, 'Susan', 'Mavris', TO_DATE('26-Nov-76', 'DD-Mon-RR'), 'AD_VP', 7500, 40);
INSERT INTO EMP VALUES (204, 'Hermann', 'Baer', TO_DATE('23-Aug-95', 'DD-Mon-RR'), 'AD_PRES', 9500, 90);
INSERT INTO EMP VALUES (205, 'Shelley', 'Higgins', TO_DATE('24-Feb-98', 'DD-Mon-RR'), 'AC_MGR', 2300, 60);
INSERT INTO EMP VALUES (206, 'William', 'Gitz', TO_DATE('12-Mar-01', 'DD-Mon-RR'), 'IT_PROG', 5000, 60);
INSERT INTO EMP VALUES (100, 'Steven', 'King', TO_DATE('15-Jun-02', 'DD-Mon-RR'), 'AD_ASST', 8956, 100);
INSERT INTO EMP VALUES (101, 'Neena', 'Kochar', TO_DATE('10-Jul-03', 'DD-Mon-RR'), 'SH_CLERK', 3400, 30);

COMMIT;
